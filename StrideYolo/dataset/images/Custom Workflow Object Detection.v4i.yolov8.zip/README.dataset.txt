# Custom Workflow Object Detection > 2025-06-27 9:25pm
https://universe.roboflow.com/arquiteturadiagram/custom-workflow-object-detection-cle4s

Provided by a Roboflow user
License: CC BY 4.0

